import RoutesWrapper from "./components/containers/RoutesWrapper";

function App() {
  return (
    <>
      <RoutesWrapper />
    </>
  );
}

export default App;
